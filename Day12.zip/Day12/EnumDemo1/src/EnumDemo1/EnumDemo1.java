package EnumDemo1;

import java.util.HashSet;
import java.util.Comparator;

class Employee
{

	int empId;
	String empName;
	Status status;

		enum Status{
			
			PENDING, COMPLETED, REJECTED;	
		}
		
		public Employee (int empId, String empName, Status status){
	
		super();
		this.empId = empId;
		this.empName = empName;
		this.status = status;
		
	}
}
	
public class EnumDemo1 {
	public static void main(String[] args) {
		HashSet <Employee> emp = new HashSet <Employee>();
		Employee emp1 = new Employee (101, "Tom", Employee.Status.PENDING);
		Employee emp2 = new Employee (102, "Jerry", Employee.Status.PENDING);
		Employee emp3 = new Employee (103, "Tony", Employee.Status.PENDING);
		
		emp.add(emp1);
		emp.add(emp2);
		emp.add(emp3);
		
		
		for(Employee e : emp) {
			System.out.println("Employee id: "+e.empId+"  "+"Emloyee Name: " +e.empName+"  "+"Status: " +e.status);
	}
	
}
}

class NameComparator implements Comparator <Employee> {

	  public int  compare (Employee o1,Employee o2) {
		  Employee E1 = (Employee) o1;
		  Employee E2 = (Employee) o2;
				return E1.empName.compareTo(E2.empName);
	  }
}

class IdComparator implements Comparator <Employee> {
	
	public int compare(Employee o1, Employee o2) {
		Employee E1 = (Employee) o1;
		Employee E2 = (Employee) o2;
			if(E1.empId==E2.empId) {
			return 0;
		}
		else if(E1.empId>E2.empId) {
				return 1;
		}
	else {
					return -1;
				}
			
	}
}

